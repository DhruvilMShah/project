package com.dbBrandStore;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


public interface OrderRepository extends JpaRepository<OrderRecord, Long> {
    List<OrderRecord> findAll();
    List<OrderRecord> findByCustomerId(long customerid);
}
