package com.dbBrandStore;


import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Product {

	@Id
	private long productId;
	private String category;
	private String productName;
	private double price;
	private String companyName;

	
	public Product() {
		
	}
	
	public Product(long productId, String category, String productName, double price, String companyName) {
		super();
		this.productId = productId;
		this.category = category;
		this.productName = productName;
		this.price = price;
		this.companyName = companyName;
	}
	
	
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}







}
