package com.dbBrandStore;


import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Customer {

	@Id
	private long customerId;
	private String password;
	private String customerName;
	private String contactNo;
	private String address;
	private String emailId;
	
	
	public Customer() {
		
	}
	
	
	
	
	public Customer(long customerId, String password, String customerName, String contactNo, String address,
			String emailId) {
		super();
		this.customerId = customerId;
		this.password = password;
		this.customerName = customerName;
		this.contactNo = contactNo;
		this.address = address;
		this.emailId = emailId;
	}
	
	
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	
		
	
}
