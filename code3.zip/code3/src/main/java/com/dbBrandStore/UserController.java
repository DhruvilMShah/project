package com.dbBrandStore;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UserController {
    
	
	@Autowired
	private CustomerRepository custRepo;
	
	@Autowired
	private ProductRepository prodRepo;
	
	@Autowired
	private OrderRepository orderRepo;
	

	@GetMapping({"/","/login"})
    public String login(Model model, String error, String logout) {
        
		
		if (error != null)
            model.addAttribute("error", "Your username or password is invalid.");

        if (logout != null)
            model.addAttribute("message", "You have been logged out successfully.");
        
        
        
        return "login.jsp";
    }
	
	@PostMapping({"/","/login"})
	public String checkUser(@RequestParam(name="userId")long userId, @RequestParam(name="password")String password) {
		
		if(custRepo.findByCustomerId(userId) != null) {
			return "welcome.jsp";
		}
		
		
		return "login.jsp";
	}
	
	
	@GetMapping("/products")
    public String listProducts(HttpServletRequest request) {
        
		System.out.println("Hello!");
		for(Product i : prodRepo.findAll()) {
			System.out.println(i);
		}
		request.setAttribute("allProducts", prodRepo.findAll());
		
        return "products.jsp";
    }


	
	@GetMapping("/orders")
    public String listOrders(HttpServletRequest request) {
        
		System.out.println("Hello!");
		for(OrderRecord i : orderRepo.findAll()) {
			System.out.println(i);
		}
		request.setAttribute("allOrders", orderRepo.findByCustomerId(1));
		
        return "orders.jsp";
    }

}

//insert into product values (1,'footwear','XYZ',1200.0,'Floaters');
//insert into product values (2,'officewear','ABC',2500.0,'Suit');

//insert into customer values (1,'12ABC Flats','1234567890','XYZ','abc@gmail.com','12345');
//insert into customer values (2,'13ABC Flats','1234567880','XYA','abc2@gmail.com','12345'); 

//insert into order values (1,1,200,1,1);
//insert into order values (2,1,400,2,1);
//insert into order values (3,2,1000,1,5);
//insert into order values (4,2,800,2,4);


